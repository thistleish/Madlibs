﻿using System;


namespace madlibs
{
    internal class Program
    {
        static void Main()
        {
            //declare variables
            string Creature;
            string Luminous;
            string Ghastly;
            string Spectral;
            string Countryman;
            string Farrier;
            string Farmer;
            string Dreadful;
            string Apparition;
            string Hound;
            string Story;

            //write out a header
            Console.WriteLine("------------");
            Console.WriteLine("| Madlibs! |");
            Console.WriteLine("------------");
            Console.ReadKey();

            //ask player to enter words
            Console.WriteLine("Please enter a noun:  ");
            Creature = Console.ReadLine();

            Console.WriteLine("Please enter an adjective:  ");
            Luminous = Console.ReadLine();

            Console.WriteLine("Please enter an adjective:  ");
            Ghastly = Console.ReadLine();

            Console.WriteLine("Please enter an adjective:  ");
            Spectral = Console.ReadLine();

            Console.WriteLine("Please enter an occupation:  ");
            Countryman = Console.ReadLine();

            Console.WriteLine("Please enter an occupation:  ");
            Farrier = Console.ReadLine();

            Console.WriteLine("Please enter an occupation:  ");
            Farmer = Console.ReadLine();

            Console.WriteLine("Please enter an adjective:  ");
            Dreadful = Console.ReadLine();

            Console.WriteLine("Please enter a noun:  ");
            Apparition = Console.ReadLine();

            Console.WriteLine("Please enter a noun:  ");
            Hound = Console.ReadLine();

            Console.WriteLine("Please enter a noun:  ");
            Story = Console.ReadLine();

            //write out the finished story
            Console.WriteLine("");
            Console.WriteLine("They all agreed that it was a huge " + Creature + ", " + Luminous + ", " + Ghastly + ", and " + Spectral + ". I have cross-examined these men, one of them a hard-headed " + Countryman + ", one a " + Farrier + ", and one a moorland " + Farmer + ", who all tell the same story of this " + Dreadful + " " + Apparition + ", exactly corresponding to the Hell-" + Hound + " of the legend.");
            Console.ReadKey();





            //keep window open


        }
    }
}
